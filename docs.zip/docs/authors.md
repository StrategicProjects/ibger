# Authors and Citation

## Authors

- **Andre Leite**. Author, maintainer.

- **Marcos Wasilew**. Author.

- **Hugo Vasconcelos**. Author.

- **Carlos Amorin**. Author.

- **Diogo Bezerra**. Author.

## Citation

Source:
[`DESCRIPTION`](https://github.com/StrategicProjects/ibger/blob/HEAD/DESCRIPTION)

Leite A, Wasilew M, Vasconcelos H, Amorin C, Bezerra D (2026). *ibger:
Access the IBGE (Brazilian Institute of Geography and Statistics)
Aggregate Data 'API'*. R package version 0.1.0,
<https://github.com/StrategicProjects/ibger>.

    @Manual{,
      title = {ibger: Access the IBGE (Brazilian Institute of Geography and Statistics) Aggregate Data 'API'},
      author = {Andre Leite and Marcos Wasilew and Hugo Vasconcelos and Carlos Amorin and Diogo Bezerra},
      year = {2026},
      note = {R package version 0.1.0},
      url = {https://github.com/StrategicProjects/ibger},
    }
