# Articles

### All vignettes

- [Understanding the IBGE Aggregate Data
  API](https://monitoramento.sepe.pe.gov.br/ibger/articles/api-concepts.md):
- [Getting started with
  ibger](https://monitoramento.sepe.pe.gov.br/ibger/articles/getting-started.md):
- [Real-world example: IPCA
  inflation](https://monitoramento.sepe.pe.gov.br/ibger/articles/ipca-example.md):
- [Tracking state GDP components with IBGE
  data](https://monitoramento.sepe.pe.gov.br/ibger/articles/tutorial.md):
