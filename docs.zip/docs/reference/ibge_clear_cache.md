# Clear metadata cache

Removes all cached metadata (aggregates and surveys), forcing fresh API
calls on subsequent requests.

## Usage

``` r
ibge_clear_cache()
```
